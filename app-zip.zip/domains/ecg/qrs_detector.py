"""
Qrs Detector module.
"""
