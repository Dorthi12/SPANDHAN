"""
Severity module.
"""
