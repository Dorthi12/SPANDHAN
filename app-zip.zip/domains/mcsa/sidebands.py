"""
Sidebands module.
"""
