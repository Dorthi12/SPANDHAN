"""
Analyzer module.
"""
