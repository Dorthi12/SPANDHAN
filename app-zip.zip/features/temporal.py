"""
Temporal module.
"""
