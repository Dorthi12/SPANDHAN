"""
Energy module.
"""
