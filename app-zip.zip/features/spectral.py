"""
Spectral module.
"""
