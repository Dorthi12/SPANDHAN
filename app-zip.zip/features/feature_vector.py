"""
Feature Vector module.
"""
