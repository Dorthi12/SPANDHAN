"""
Statistical module.
"""
