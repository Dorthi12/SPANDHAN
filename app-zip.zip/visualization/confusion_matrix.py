"""
Confusion Matrix module.
"""
