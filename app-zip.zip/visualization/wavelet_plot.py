"""
Wavelet Plot module.
"""
