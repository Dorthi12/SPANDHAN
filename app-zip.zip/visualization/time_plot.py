"""
Time Plot module.
"""
