"""
Cepstrum Plot module.
"""
