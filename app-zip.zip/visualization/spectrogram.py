"""
Spectrogram module.
"""
