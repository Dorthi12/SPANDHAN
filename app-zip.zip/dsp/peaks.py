"""
Peaks module.
"""
