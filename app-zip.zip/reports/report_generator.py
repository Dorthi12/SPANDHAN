"""
Report Generator module.
"""
