"""
Recommendations module.
"""
