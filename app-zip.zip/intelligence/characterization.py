"""
Characterization module.
"""
