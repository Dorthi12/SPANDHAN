"""
Diagnosis module.
"""
