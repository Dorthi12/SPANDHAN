"""
Fusion module.
"""
