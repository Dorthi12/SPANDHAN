"""
Feature Extractor module.
"""
