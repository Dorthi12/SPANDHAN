"""
Evaluator module.
"""
