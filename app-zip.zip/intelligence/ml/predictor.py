"""
Predictor module.
"""
