"""
Trainer module.
"""
