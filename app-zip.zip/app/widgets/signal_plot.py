"""
Signal Plot module.
"""
