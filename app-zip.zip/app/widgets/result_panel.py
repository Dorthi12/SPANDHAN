"""
Result Panel module.
"""
