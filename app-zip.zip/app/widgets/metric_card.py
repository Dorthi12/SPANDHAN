"""
Metric Card module.
"""
