"""
Main Window module.
"""
