"""
Ml Page module.
"""
