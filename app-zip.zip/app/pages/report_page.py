"""
Report Page module.
"""
