"""
Settings Page module.
"""
