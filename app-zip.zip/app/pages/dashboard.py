"""
Dashboard module.
"""
