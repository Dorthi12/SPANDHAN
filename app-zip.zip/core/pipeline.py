"""
Pipeline module.
"""
