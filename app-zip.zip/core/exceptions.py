"""
Exceptions module.
"""
