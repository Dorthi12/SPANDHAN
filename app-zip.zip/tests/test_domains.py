"""
Test Domains module.
"""
